module.exports = {
  HOST: "localhost",
  USER: "id19605742_natuan0207",
  PASSWORD: "Natuan_020701",
  DB: "id19605742_todo_app",
  PORT: 3306,
};
